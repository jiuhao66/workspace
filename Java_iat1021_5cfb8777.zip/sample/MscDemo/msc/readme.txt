该目录下放置msc.cfg文件，文件下载地址参考讯飞bbs论坛：
http://bbs.xfyun.cn/forum.php?mod=viewthread&tid=9870&highlight=%E5%90%84%E5%B9%B3%E5%8F%B0

