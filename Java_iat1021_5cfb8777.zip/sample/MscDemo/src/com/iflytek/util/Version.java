package com.iflytek.util;

public class Version {
	/**
	 * 获取控件版本号
	 * @return
	 */
	public static String getVersion()
	{
		return "2.0.1020.1178";
	}
	
	public static String getAppid()
	{
		return "5cfb8777";
	}
}
